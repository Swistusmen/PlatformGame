#include <iostream>
#include <SFML/Graphics.hpp>
#include "Utilities.hpp"
#include "Mechanics.hpp"

//Cel: - ukoñczyæ aplikacje w ten sposób ¿eby wyœwietla³a 3 obiekty, gracza, wroga i pod³o¿e //JEST

//Krok 2: -wprowadzic proste komendy gracza, i to by na nie reagowa³, wprowadziæ ruchy jednostek
//wa¿ne przy tym ¿eby sterowanie graczem odbywa³o siê przy u¿yciu komend i ¿eby oddzieliæ to od zmiany stanu gry
//a) przeczytac w jaki sposob zgłaszać to w real time-JEST
//b) stworzyć struktury bedace komendami i kolejke komend -JEST
//c) stworzyc sposob odbioru i dystrybucji komend->dokonczyc funckej w Game i ta ponizej-JEST
//d) stworyc sposob aby odpowiednie komendy trafialydo odppowiednich obiektow- JEST
//jak wywolac funkcje na sobie???-JEST

//krok 3: wdrozenie automatow, dopracowanie funkcji bedacych automatami JEST

//krok : -system wykrywania kolizji
//1. poczytac o architekturze
//2. ustalic jak ma dochodzic do wykrywania kolizji
//3. zaimplementowac

//obsluga kolizji tylko od gracza, i ewentualnych elementow typu pocisk itd, ale obiekty automatyczne maja nie
//kolidowac ze soba i za to odpowiadam ja tworzac automaty- Jest to bardzo prosty mechanizm i nie do stosowania
//ma dluzsza mete

void Entity::SetPhysics(Physics&& fizyka)
{
    fizykagracza=fizyka;
}

void Level::MakeCollision(Position& pozycja,ObjectTypes& obj )
{
    std::cout<<"make collision\n";
   switch(obj)
   {
   case ObjectTypes::Ground:
    {
        std::cout<<"ground\n";
        //if(pozycja==Position::Dol)
        //{
            std::cout<<"Dol"<<std::endl;
            Hero->SetPhysics(Physics::Normal);
        //}
        //else Hero->SetPhysics(Physics::Fall);
    }break;
   case ObjectTypes::Kroczacy:
    {
        std::cout<<"dead"<<std::endl;
    }break;
   }
}

Position Entity::DoShapesCover(sf::FloatRect& kwadrat)
{
    sf::FloatRect obiekt=this->RetTheShape();
    bool DoThey=kwadrat.intersects(obiekt);
    if(DoThey==1)//zawieraja sie
    {
        ObjectTypes typek=this->WhatsTheObjectType();
        Position uziemienie;
        int a1=obiekt.left-1, a2=kwadrat.left;
        int w1=obiekt.top-1,  w2=kwadrat.top;
        int d1=obiekt.width+a1+1, d2=kwadrat.width+a2;
        int s1=w1+obiekt.height+1, s2=w2+kwadrat.height;
        int centreheight=(s2-w2)/2;
        int centreweight=(d2-a2)/2;
        //przypadek gdy gracz z lewej
        if((a2>=a1)&&(centreheight<=s1)&&(centreheight>=w1))
        {
            uziemienie=Position::Lewo;
        }
        else if((d2<=d1)&&(centreheight<=s1)&&(centreheight>=w1)){//przypadek prawa
            uziemienie=Position::Prawo;
        }
        if((w2>=w1)&&(centreweight<=s1)&&(centreweight>=w1))//przypadek gora
        {
            uziemienie=Position::Gora;
        }
        else if((s2<=s1)&&(centreheight<=s1)&&(centreheight>=w1)){//przypadek dol
            uziemienie=Position::Dol;
        }
        return uziemienie;

    }
    return Position::Nie;
}

void Level::CheckCollisions()
{
    Position DoThey;
    sf::FloatRect kwadrat=Hero->RetTheShape();
    std::vector<std::unique_ptr<Entity>>::iterator it;
    for(it=FirstPlan.begin();it!=FirstPlan.end();it++)
    {
        DoThey=(*it)->DoShapesCover(kwadrat);
        if(DoThey!=Position::Nie)
        {
            std::cout<<"1st "<<DoThey<<std::endl;
            MakeCollision(DoThey,(*it)->WhatsTheObjectType());
        }
    }
    for(it=SecondPlan.begin();it!=SecondPlan.end();it++)
    {
        DoThey=(*it)->DoShapesCover(kwadrat);
        if(DoThey!=Position::Nie)
        {
            std::cout<<"2nd "<<DoThey<<std::endl;
            MakeCollision(DoThey,(*it)->WhatsTheObjectType());
        }
    }

}

const sf::FloatRect& Entity::RetTheShape()
{
    return std::move( sprite.getGlobalBounds());
}

void Level::Ruch()
{
    std::vector<std::unique_ptr<Entity>>::iterator it;
    for(it=FirstPlan.begin();it!=FirstPlan.end();it++)
        (*it)->Ruch();
    (Hero)->Ruch();
}

void Player::Ruch()
{
    std::cout<<"fizyka "<<fizykagracza<<std::endl;
    switch(fizykagracza)
    {
    case Physics::Normal:
        {
         placement.y=placement.y;
         licznik=0;
        }break;
    case Physics::Jump:
        {
            if(licznik<7){
                placement.y-=SKOK_GRACZ;
                licznik++;
            }
            else{
                licznik=0;
                fizykagracza=Physics::Fall;
                break;
            }
        }break;
    case Physics::Fall:
        {
                placement.y+=SPADANIE;
        }break;
    }
}

void Enemy::Ruch()
{
    if(licznik<20)
        licznik++;
    else
    {
        licznik=0;
        stan==EnemyWalk::Backward?stan=EnemyWalk::Forward:stan=EnemyWalk::Backward;
    }
    stan==EnemyWalk::Forward?placement.x+=WROG_RUCH:placement.x-=WROG_RUCH;
}

void Level::DistributeTheCommand(std::function<void (Entity&)>& funkcja,ObjectTypes& typobiektu)
{
    std::vector<std::unique_ptr<Entity>>::iterator it;
    switch(typobiektu)
    {
    case ObjectTypes::Gracz:
        {
            try{
            funkcja(*Hero);
            }catch(std::bad_function_call& e){std::cout<<e.what()<<std::endl;};
        }break;
    case ObjectTypes::Kroczacy:
        {
            for(it=FirstPlan.begin();it!=FirstPlan.end();it++);
               if((*it)->WhatsTheObjectType()==typobiektu)
                    funkcja(*(*it));
        }break;
    case ObjectTypes::Ground: case ObjectTypes::Sky:
        {
            for(it=SecondPlan.begin();it!=SecondPlan.end();it++)
                if((*it)->WhatsTheObjectType()==typobiektu)
                    funkcja(*(*it));
        }break;
    default:
        {
            return;
        }break;
    }
}

ObjectTypes& Entity::WhatsTheObjectType()
{
    return TypOfObject;
}

void Level::update()
{
    std::vector<std::unique_ptr<Entity>>::iterator it;
    for(it=SecondPlan.begin();it!=SecondPlan.end();it++)
        (*it)->update();
    for(it=FirstPlan.begin();it!=FirstPlan.end();it++)
        (*it)->update();
    Hero->update();
}

void Dirt::update()
{
    sprite.setPosition(placement);
}

void Enemy::update()
{
    //Ruch();
    sprite.setPosition(placement);
}

void Player::update()
{
    //Ruch();
    sprite.setPosition(placement);
}

void Entity::Pion(int ruch)
{
    if(fizykagracza==Physics::Normal)
        fizykagracza=Physics::Jump;
       // placement.y+=ruch;
}

void Entity::Poziom(int ruch)
{
    placement.x+=ruch;
}

Entity::Entity(sf::Texture& teksturka, ObjectTypes&& typ, sf::IntRect& a,sf::Vector2f& polozenie)
{
    TypOfObject=typ;
    sprite.setTexture(teksturka);
    sprite.setTextureRect(sf::IntRect(a));
    placement=polozenie;
    sprite.setPosition(polozenie);
}

Dirt::Dirt(sf::Texture& teksturka,ObjectTypes&& typ, sf::Vector2f& polozenie,sf::Vector2f& scale,sf::IntRect& a):Entity(teksturka,std::move(typ),a,polozenie)
{
    //sprite.setPosition(polozenie);
    //sprite.setScale(scale);
    teksturka.setRepeated(true);
}

void Level::addEntity(std::unique_ptr<Entity> wsk, Layer przyporzadkowanie)
{
    switch (przyporzadkowanie)
    {
    case Layer::Forground:
        {
            FirstPlan.push_back(std::move(wsk));
        }break;
    case Layer::Background:
        {
            SecondPlan.push_back(std::move(wsk));
        }break;
    }
}

void Level::addHero(TextureHolder& holder)
{
    sf::Vector2f polozenie {100,100};
    sf::Vector2f scale {1,1};
    std::unique_ptr<Entity> wsk(new Player (holder.GetTexture(ObjectTypes::Gracz),ObjectTypes::Gracz,polozenie,scale));

    Hero=std::move(wsk);
}

void Level::addHero(std::unique_ptr<Entity> bohater)
{
    Hero=std::move(bohater);
}

Level::Level(std::unique_ptr<Entity> bohater)
{
    Hero=std::move(bohater);
}

void Level::draw(sf::RenderWindow& appwindow)
{
    std::vector<std::unique_ptr<Entity>>::iterator it;
    for(it=SecondPlan.begin();it!=SecondPlan.end();it++)
        (*it)->draw(appwindow);
    for(it=FirstPlan.begin();it!=FirstPlan.end();it++)
        (*it)->draw(appwindow);
    Hero->draw(appwindow);

}

Dirt::Dirt(sf::Texture& teksturka,ObjectTypes&& typ, sf::Vector2f& polozenie,sf::Vector2f& skala):Entity(teksturka,std::move(typ),polozenie)
{
    //sprite.setPosition(polozenie);
    sprite.setScale(skala);
}

Enemy::Enemy(sf::Texture& teksturka,ObjectTypes&& typ, sf::Vector2f& polozenie,sf::Vector2f& skala):Entity(teksturka,std::move(typ),polozenie)
{
    //sprite.setPosition(polozenie);
    sprite.setScale(skala);
}

Player::Player(sf::Texture& teksturka,ObjectTypes&& typ, sf::Vector2f& polozenie,sf::Vector2f& skala):Entity(teksturka,std::move(typ),polozenie)
{
    //sprite.setPosition(polozenie);
    sprite.setScale(skala);
}

void Entity::draw(sf::RenderWindow& appwindow)
{
    appwindow.draw(sprite);
}

Entity::Entity(sf::Texture& teksturka, ObjectTypes&& typ, sf::Vector2f& polozenie)
{
    TypOfObject=typ;
    sprite.setTexture(teksturka);
    placement=polozenie;
    sprite.setPosition(polozenie);
}
