#include <iostream>
#include <map>
#include <memory>
#include <SFML/Graphics.hpp>
#include <string>
#include "Utilities.hpp"

void TextureHolder::LoadFromFile(ObjectTypes przyporzadkowanie,std::string&& pathname)
{
    std::unique_ptr<sf::Texture> wsk (new sf::Texture);
    if(!wsk->loadFromFile(pathname))
    {
        std::cerr<<"Blad we wczytywaniu tekstury z pliku\n";
        exit(EXIT_FAILURE);
    }
    mapa.insert(std::make_pair(przyporzadkowanie,std::move(wsk)));
}

sf::Texture& TextureHolder::GetTexture(ObjectTypes rodzaj)
{
    auto znalezione=mapa.find(rodzaj);
    if(znalezione==mapa.end())
    {
        std::cerr<<"Nie znaleziono tekstury "<<rodzaj<<std::endl;
        exit(EXIT_FAILURE);
    }
    return *znalezione->second;
}
