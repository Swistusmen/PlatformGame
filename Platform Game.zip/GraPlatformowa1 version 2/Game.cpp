#include <iostream>
#include <SFML/Graphics.hpp>
#include"Mechanics.hpp"
#include "Utilities.hpp"
#include "Game.hpp"

void Game::Run()
{
    appwindow.create(sf::VideoMode(2800,1400,32),"okno");

    sf::Time TimeSinceLastUpdate;
    sf::Clock timer;
    sf::Time DeltaTime=sf::seconds(1.f/20.f);

    while(appwindow.isOpen())
    {
        HandleEvent();
        TimeSinceLastUpdate+=timer.restart();
            if(TimeSinceLastUpdate>=DeltaTime)
            {
            ProcessInput();

            DistributeTheCommands();
            update();//funkcja sprawdzajaca kolizje znajduje sie w update, ma byc w kodzie jak najpozniej, to dlatego
            draw();

            TimeSinceLastUpdate-=DeltaTime;
            }
        ProcessEvent();
    }
}

void Game::DistributeTheCommands()
{
    while(Orders.IsEmpty()==0)
    {
        command bufor=Orders.pop();
        poziom.DistributeTheCommand(bufor.GetAFunction(),bufor.GetObjectTypes());
    }
}

void Game::update()
{
    poziom.Ruch();
    poziom.CheckCollisions();
    poziom.update();
}

void Game::ProcessInput()
{
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::A))
    {
        auto f=[](Entity& obiekt){obiekt.Poziom(-GRACZ_W_BOK);};
        command bufor {f,ObjectTypes::Gracz};
        Orders.push(bufor);
        std::cout<<"Wcisenito A"<<std::endl;
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::D))
    {
        auto f=[](Entity& obiekt){obiekt.Poziom(GRACZ_W_BOK);};
        command bufor {f,ObjectTypes::Gracz};
        Orders.push(bufor);
        std::cout<<"Wcisnieto D"<<std::endl;
    }
    if(sf::Keyboard::isKeyPressed(sf::Keyboard::Space))
    {
        auto f=[](Entity& obiekt){obiekt.Pion(-SKOK_GRACZ);};
        command bufor {f};
        Orders.push(bufor);
        std::cout<<"Wcisnieto Spacje"<<std::endl;
    }
}

Game::Game()
{
    Holder.LoadFromFile(ObjectTypes::Ground,"dirt.jpg");
    Holder.LoadFromFile(ObjectTypes::Gracz,"player.jpg");
    Holder.LoadFromFile(ObjectTypes::Kroczacy,"enemy.jpg");

    sf::Vector2f polozenie {100,100};
    sf::Vector2f scale {1,1};
    std::unique_ptr<Entity> wsk(new Player (Holder.GetTexture(ObjectTypes::Gracz),ObjectTypes::Gracz,polozenie,scale));
    poziom.addHero(std::move(wsk));

    polozenie.x=1700;
    polozenie.y=1200;
    std::unique_ptr<Entity> ptr (new Enemy (Holder.GetTexture(ObjectTypes::Kroczacy),ObjectTypes::Kroczacy,polozenie,scale));
    poziom.addEntity(std::move(ptr),Layer::Forground);

    polozenie.x=0;
    polozenie.y=1300;
    scale.x=28;
    scale.y=2;
    sf::IntRect kwadrat (0,1300,2800,100);
    //ptr.reset (new Dirt (Holder.GetTexture(ObjectTypes::Ground),ObjectTypes::Ground,polozenie,scale));
    ptr.reset (new Dirt (Holder.GetTexture(ObjectTypes::Ground),ObjectTypes::Ground,polozenie,scale,kwadrat ));
    poziom.addEntity(std::move(ptr),Layer::Background);

    //dodac ziemie !!!!!!!!!!!!!!


    stanGry=GameStates::Play;
}

void Game::ProcessEvent()
{
    if(stanGry==GameStates::Closing)
    {
        appwindow.close();
        exit(EXIT_SUCCESS);
    }
}

void Game::HandleEvent()
{
    sf::Event zdarzenie;
   while(appwindow.pollEvent(zdarzenie))
   {
       switch (zdarzenie.type)
       {
           case sf::Event::Closed:
           {
               stanGry=GameStates::Closing;
           }break;
        default:{
        }break;

       }
   }
}

void Game::draw()
{
    poziom.draw(appwindow);
    appwindow.display();
    appwindow.clear();
}
