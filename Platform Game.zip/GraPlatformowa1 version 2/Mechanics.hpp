#ifndef MECHANICS_HPP_INCLUDED
#define MECHANICS_HPP_INCLUDED



#endif // MECHANICS_HPP_INCLUDED
#include <iostream>
#include <memory>
#include <SFML/Graphics.hpp>
#include "Utilities.hpp"
#include <vector>



#pragma once

class Entity{
public:
Entity(sf::Texture& ,ObjectTypes&& ,sf::Vector2f& );
Entity(sf::Texture& ,ObjectTypes&&, sf::IntRect&, sf::Vector2f& );
void draw(sf::RenderWindow& );
virtual void update()=0;
virtual void Ruch()=0;

void Poziom(int );
void Pion(int );
ObjectTypes& WhatsTheObjectType();

const sf::FloatRect& RetTheShape();
Position DoShapesCover(sf::FloatRect& );
void SetPhysics(Physics&&);

protected:
sf::Sprite sprite;
ObjectTypes TypOfObject;
sf::Vector2f placement;
Physics fizykagracza=Physics::Normal;
};

class Player:public Entity{
public:
Player(sf::Texture& ,ObjectTypes&&, sf::Vector2f& ,sf::Vector2f&);

public:
    void update() override;
private:
    void Ruch() override;//sluzy do obs�ugi automatyczneych zachowan gracza typu skok, spadanie itd

private:
    int licznik=0;
};

class Enemy:public Entity{
public:
Enemy(sf::Texture& ,ObjectTypes&&, sf::Vector2f& ,sf::Vector2f&);

void update() override;
private:
void Ruch() override;
private: //zmienne potrzebne do automatycznego poruszania sie
EnemyWalk stan=EnemyWalk::Forward;
int licznik=0;
};

class Dirt:public Entity{
public:
void update() override;
void Ruch(){};
Dirt(sf::Texture& ,ObjectTypes&&, sf::Vector2f&, sf::Vector2f& );
Dirt(sf::Texture& ,ObjectTypes&&, sf::Vector2f&, sf::Vector2f& ,sf::IntRect& );
private:
};

class Level{
public:
    void update();

    void draw(sf::RenderWindow&);
    Level(std::unique_ptr<Entity>);
    Level()=default;

    void addHero(std::unique_ptr<Entity>);
    void addHero(TextureHolder& );

    void addEntity(std::unique_ptr<Entity>,Layer);

    void CheckCollisions();

    void DistributeTheCommand(std::function<void (Entity&)>& ,ObjectTypes&);
    void Ruch();
    void MakeCollision(Position&, ObjectTypes& );
private:
    std::vector<std::unique_ptr<Entity>> FirstPlan;
    std::vector<std::unique_ptr<Entity>> SecondPlan;
    std::unique_ptr<Entity> Hero;

private:
    std::map<ObjectTypes, std::function<void (Entity&)>> kolizje;
};



