#ifndef UTILITIES_HPP_INCLUDED
#define UTILITIES_HPP_INCLUDED



#endif // UTILITIES_HPP_INCLUDED
#include <iostream>
#include <map>
#include <memory>
#include <SFML/Graphics.hpp>
#include <string>
#include <functional>
#pragma once

#define GRACZ_W_BOK 25
#define SKOK_GRACZ 30
#define SPADANIE 25
#define WROG_RUCH 20

enum Position {Lewo, Gora, Prawo, Dol, Nie};

enum Physics {Normal, Jump, Fall};

enum EnemyWalk {Forward, Backward};

enum ObjectTypes {Gracz, Ground, Sky, Kroczacy, Nothing};

enum GameStates {Uninitialized, Play, Paused, Closing};

enum Layer {Forground,Background};


class TextureHolder{
public:
    void LoadFromFile(ObjectTypes,std::string&&);
    sf::Texture& GetTexture (ObjectTypes);
    TextureHolder()=default;
private:
    std::map<ObjectTypes,std::unique_ptr<sf::Texture>> mapa;
};
