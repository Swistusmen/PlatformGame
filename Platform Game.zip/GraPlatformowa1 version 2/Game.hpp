#ifndef GAME_HPP_INCLUDED
#define GAME_HPP_INCLUDED



#endif // GAME_HPP_INCLUDED
#include <iostream>
#include <SFML/Graphics.hpp>
#include"Mechanics.hpp"
#include "Utilities.hpp"
#include "Controler.hpp"
#pragma once

#SZEROKOSC_OKNA 2800
#WYSOKOSC_OKNA 1400

class Game{
public:
    void Run();
    Game();
private:
    void draw();
    void update();

private:
    void HandleEvent();
    void ProcessEvent();//ta i powyzsza funkcja sa stosowane do zmiany stanu gry
    void ProcessInput();//pobieranie inputu w real time i wydawanie komend bohaterowi

    void DistributeTheCommands();
private:

    CommandQueue Orders;
    Level poziom;
    TextureHolder Holder;
    sf::RenderWindow appwindow;
    GameStates stanGry=Uninitialized;

};
