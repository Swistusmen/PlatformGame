#ifndef CONTROLER_HPP_INCLUDED
#define CONTROLER_HPP_INCLUDED



#endif // CONTROLER_HPP_INCLUDED
#include <iostream>
#include <functional>
#include <memory>
#include <list>
#include <queue>
#include "Mechanics.hpp"
#include "Utilities.hpp"
#pragma once

class command{//potrzebna bêdzie funkcja klasy Level która przyjmuje ObjectTypes i std::function
    //koniecznie trzeba dodać operator przypisujacy
public:
    command(std::function<void (Entity&)>& , ObjectTypes&& =ObjectTypes::Gracz);
    command(std::function<void (Entity&)>&& , ObjectTypes&& =ObjectTypes::Gracz);
    command()=default;
public:
    ObjectTypes& GetObjectTypes();//zwraca typ obiektu
    std::function<void (Entity&)>& GetAFunction();//zwraca samą funckje
private:
    std::function<void (Entity& )> akcja;
    ObjectTypes przyporzadkowanie;
};

class CommandQueue{
public:
    CommandQueue()=default;
    void push(const command& komenda);
    command pop();
    bool IsEmpty();
private:
    std::queue<command> kolejka;
};



